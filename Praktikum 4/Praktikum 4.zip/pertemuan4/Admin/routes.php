<?php
$ar_menu =[
    'Home' => 'index.php',
    'Daftar' => 'daftar.php',
    'Array Buah' => 'array_buah.php',
    'Belanja' => 'form_belanja.php',
    'Siswa Nilai' => 'form_nilai.php'
];